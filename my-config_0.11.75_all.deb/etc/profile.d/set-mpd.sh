MPD_HOST=/run/user/${UID}/mpd.socket
export MPD_PORT=6${UID}
